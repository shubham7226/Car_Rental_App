﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Car_Rental_App.Models
{
    public class AppDbContext : IdentityDbContext<Customer>
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {

        }
        
        public DbSet<Customer> Customers { get; set; }

        public DbSet<Car> cars { get; set; }

        public DbSet<Driver> Drivers { get; set; }

        public DbSet<Reservation> Reservations { get; set; }

        public DbSet<PostData> PostDatas { get; set; }

        public DbSet<DebitCard> DebitCards { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            
            modelBuilder.Entity<Reservation>().
                    HasOne(pt => pt.Car).WithMany(pt => pt.Reservations).HasForeignKey(p => p.CarId);

            modelBuilder.Entity<Reservation>().
                    HasOne(pt => pt.Customer).WithMany(pt => pt.Reservations).HasForeignKey(p => p.CustomerId);
        }
    }
}
