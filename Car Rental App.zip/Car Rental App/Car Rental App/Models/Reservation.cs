﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Car_Rental_App.Models
{
    public class Reservation
    {
        [Key]
        public int ReservationId { get; set; }

        [Required]
        public string PickupLocation { get; set; }

        [Required]
        public string DropLocation { get; set; }

        [Required]
        [DataType(DataType.Date)]
        public DateTime PickupDate { get; set; }

        [Required]
        [DataType(DataType.Date)]
        public DateTime DropDate { get; set; }

        [Required]
        public int Amount { get; set; }

        [Required]
        public String CarVIN { get; set; }

        [DataType(DataType.Date)]
        public DateTime BookingTime { get; set; }

        //Reference navigation property
        public int CarId { get; set; }
        public Car Car { get; set; }

        public string CustomerId { get; set; }
        public Customer Customer { get; set; }

        public int Driver_Id { get; set; }
        public Driver Driver { get; set; }
    }
}
