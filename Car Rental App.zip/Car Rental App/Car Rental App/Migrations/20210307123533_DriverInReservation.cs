﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Car_Rental_App.Migrations
{
    public partial class DriverInReservation : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "DriverId",
                table: "Reservations",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "Driver_Id",
                table: "Reservations",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Reservations_DriverId",
                table: "Reservations",
                column: "DriverId");

            migrationBuilder.AddForeignKey(
                name: "FK_Reservations_Drivers_DriverId",
                table: "Reservations",
                column: "DriverId",
                principalTable: "Drivers",
                principalColumn: "DriverId",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Reservations_Drivers_DriverId",
                table: "Reservations");

            migrationBuilder.DropIndex(
                name: "IX_Reservations_DriverId",
                table: "Reservations");

            migrationBuilder.DropColumn(
                name: "DriverId",
                table: "Reservations");

            migrationBuilder.DropColumn(
                name: "Driver_Id",
                table: "Reservations");
        }
    }
}
