﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Car_Rental_App.Migrations
{
    public partial class RentPerDay_InCar : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "RentPerDay",
                table: "cars",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "RentPerDay",
                table: "cars");
        }
    }
}
