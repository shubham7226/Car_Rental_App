﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Car_Rental_App.ViewModel
{
    public class PostDataViewModel
    {
        public string title { get; set; }

        public string textfile { get; set; }
    }
}
