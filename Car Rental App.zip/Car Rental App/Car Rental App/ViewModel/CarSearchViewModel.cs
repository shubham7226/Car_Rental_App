﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Car_Rental_App.ViewModel
{
    public class CarSearchViewModel
    {
        [Required]
        public string Source { get; set; }

        [Required]
        public string Destination { get; set; }

        [DataType(DataType.Date)]
        public DateTime PickupDate { get; set; }

        [DataType(DataType.Date)]
        public DateTime DropDate { get; set; }
    }
}
