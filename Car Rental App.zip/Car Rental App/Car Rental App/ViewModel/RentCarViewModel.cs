﻿using Car_Rental_App.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Car_Rental_App.ViewModel
{
    public class RentCarViewModel : CarSearchViewModel
    {
        public int Id { get; set; }
        public RentCarViewModel()
        {
            cars = new List<Car>();
        }
        public List<Car> cars { get; set; }

    }
}
