﻿using Car_Rental_App.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Car_Rental_App.Controllers
{
    public class PaymentController : Controller
    {
        private readonly AppDbContext _context;

        private readonly UserManager<Customer> userManager;
        private readonly SignInManager<Customer> signInManager;
        public PaymentController(AppDbContext context,
                             UserManager<Customer> userManager,
                             SignInManager<Customer> signInManager)
        {
            _context = context;
            this.userManager = userManager;
            this.signInManager = signInManager;
        }
        [HttpGet]
        public IActionResult AddDebitCard()
        {
            return View();
        }

        public async Task<IActionResult> AddDebitCard(DebitCard debitCard)
        {
            if (ModelState.IsValid)
            {
                var user = await _context.Customers.FindAsync(userManager.GetUserId(HttpContext.User));
                DebitCard newCard = new DebitCard
                {
                    CardHolderId = user.Id,
                    CardHolderName = debitCard.CardHolderName,
                    CardNumber = debitCard.CardNumber,
                    CVV = debitCard.CVV,
                    ExpiryDate = debitCard.ExpiryDate
                };
                _context.Add(newCard);
                _context.SaveChanges();
                return RedirectToAction("DebitCards", "Payment");
            }
            return View();
        }

        public async Task<IActionResult> DebitCards()
        {
            var LoogedInUser = await _context.Customers.FindAsync(userManager.GetUserId(HttpContext.User));
            var DebitCards = _context.DebitCards.ToList();
            List<DebitCard> MyCards = new List<DebitCard>();
            foreach (var item in DebitCards)
            {
                if (item.CardHolderId == LoogedInUser.Id)
                {
                    MyCards.Add(item);
                }
            }
            return View(MyCards);
        }

        [HttpGet]
        public IActionResult Pay(int CarId, int DriverId, string source, string destination, string StartDate, string EndDate)
        {
            ViewBag.CarId = CarId;
            ViewBag.DriverId = DriverId;
            ViewBag.source = source;
            ViewBag.destination = destination;
            ViewBag.StartDate = StartDate;
            ViewBag.EndDate = EndDate;
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Pay(DebitCard model, int CarId, int DriverId, string source, string destination, string StartDate, string EndDate)
        {
            var LoggedInUser = await _context.Customers.FindAsync(userManager.GetUserId(HttpContext.User));
            var card = _context.DebitCards.Where(x => x.CardNumber == model.CardNumber).ToList();
            if (card.Count == 1 && model.CardHolderName == card[0].CardHolderName && model.CVV == card[0].CVV &&
                model.ExpiryDate == card[0].ExpiryDate)
            {
                Driver SelectDriver = null;
                if (DriverId.ToString() != null)
                    SelectDriver = await _context.Drivers.FindAsync(DriverId);
                var rentCar = await _context.cars.FindAsync(CarId);
                Reservation newReservation = new Reservation
                {
                    PickupLocation = source,
                    DropLocation = destination,
                    PickupDate = Convert.ToDateTime(StartDate),
                    DropDate = Convert.ToDateTime(EndDate),
                    CarVIN = rentCar.VIN,
                    Car = rentCar,
                    BookingTime = DateTime.Now,
                    Driver = SelectDriver,
                    Customer = await _context.Customers.FindAsync(userManager.GetUserId(HttpContext.User))
                };
                if(SelectDriver == null)
                    newReservation.Driver_Id = 0;
                else
                    newReservation.Driver_Id = SelectDriver.DriverId;
                newReservation.Amount = 0;
                int CarRent = (int)((newReservation.DropDate - newReservation.PickupDate).TotalDays + 1) * rentCar.RentPerDay;
                int DriverRent = (int)((newReservation.DropDate - newReservation.PickupDate).TotalDays + 1) * 500;
                if (SelectDriver != null)
                    newReservation.Amount = CarRent + DriverRent;
                else
                    newReservation.Amount = CarRent;
                _context.Reservations.Add(newReservation);
                _context.SaveChanges();
                return RedirectToAction("RentedCars", "Rental");
            }
            ViewBag.ErrorMessage = "Incorrect Credential";
            return View(model);
        }
    }
}
