﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Car_Rental_App.Models;
using Car_Rental_App.ViewModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Car_Rental_App.Controllers
{
    [Authorize(Roles = "Admin")]
    public class CarController : Controller
    {
        private readonly AppDbContext _context;

        private readonly UserManager<Customer> userManager;
        private readonly IWebHostEnvironment hostingEnvironment;

        public CarController(AppDbContext context,
                            IWebHostEnvironment hostingEnvironment,
                             UserManager<Customer> userManager)
        {
            _context = context;
            this.userManager = userManager;
            this.hostingEnvironment = hostingEnvironment;
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(CarCreateViewModel model)
        {
            if (ModelState.IsValid)
            {
                string uniqueFileName = ProcessUploadedFile(model);

                Car newCar = new Car
                {
                    CarName = model.CarName,
                    RentPerDay = model.RentPerDay,
                    Color = model.Color,
                    Category = model.Category,
                    VIN = model.VIN,
                    CarDescription = model.CarDescription,
                    CarModel = model.CarModel,
                    Brand = model.Brand,
                    Seats = model.Seats,
                    PhotoPath = uniqueFileName
                };

                _context.Add(newCar);
                _context.SaveChanges();
                return RedirectToAction("index", "car");
            }
            return View();
        }


        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            var car = await _context.cars.FindAsync(id);
            CarEditViewModel carEditViewModel = new CarEditViewModel
            {
                Id = car.CarId,
                CarName = car.CarName,
                RentPerDay = car.RentPerDay,
                Color = car.Color,
                Category = car.Category,
                VIN = car.VIN,
                CarDescription = car.CarDescription,
                CarModel = car.CarModel,
                Seats = car.Seats,
                Brand = car.Brand,
                ExistingPhotoPath = car.PhotoPath
            };
            return View(carEditViewModel);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(CarEditViewModel model)
        {
            if (ModelState.IsValid)
            {
                Car car = await _context.cars.FindAsync(model.Id);
                car.CarName = model.CarName;
                car.Color = model.Color;
                car.RentPerDay = model.RentPerDay;
                car.Category = model.Category;
                car.VIN = model.VIN;
                car.CarDescription= model.CarDescription;
                car.CarModel= model.CarModel;
                car.Seats= model.Seats;
                car.Brand= model.Brand;
                
                if (model.Photo != null)
                {
                    if (model.ExistingPhotoPath != null)
                    {
                        string filePath = Path.Combine(hostingEnvironment.WebRootPath,
                            "images", model.ExistingPhotoPath);
                        System.IO.File.Delete(filePath);
                    }
                    car.PhotoPath = ProcessUploadedFile(model);
                }
                _context.Update(car);
                await _context.SaveChangesAsync();

                return RedirectToAction("index", "car");
            }
            return View(model);
        }

        private string ProcessUploadedFile(CarCreateViewModel model)
        {
            string uniqueFileName = null;

            if (model.Photo != null)
            {
                string uploadsFolder = Path.Combine(hostingEnvironment.WebRootPath, "images");
                uniqueFileName = Guid.NewGuid().ToString() + "_" + model.Photo.FileName;
                string filePath = Path.Combine(uploadsFolder, uniqueFileName);
                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    model.Photo.CopyTo(fileStream);
                }
            }

            return uniqueFileName;
        }

        [AllowAnonymous]
        public async Task<IActionResult> Index()
        {
            return View(await _context.cars.ToListAsync());
        }


        [AllowAnonymous]
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var car = await _context.cars
                .FirstOrDefaultAsync(m => m.CarId== id);
            if (car == null)
            {
                Response.StatusCode = 404;
                return View("CarNotFound", id);
            }

            return View(car);
        }

        [HttpGet]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var car = await _context.cars
                .FirstOrDefaultAsync(m => m.CarId == id);
            if (car == null)
            {
                Response.StatusCode = 404;
                return View("CarNotFound", id);
            }
            return View(car);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var car = await _context.cars.FindAsync(id);
            string filePath = Path.Combine(hostingEnvironment.WebRootPath,
                            "images", car.PhotoPath);
            System.IO.File.Delete(filePath);
            _context.cars.Remove(car);
            await _context.SaveChangesAsync();
            return RedirectToAction("index", "car");
        }
    }
}
