﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Car_Rental_App.Models;
using Microsoft.AspNetCore.Identity;

namespace Car_Rental_App.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly AppDbContext _context;
        private UserManager<Customer> userManager;

        public HomeController(AppDbContext context,
                                UserManager<Customer> UserManager,
                                ILogger<HomeController> logger)
        {
            _logger = logger;
            _context = context;
            userManager = UserManager;
        }


        public async Task<IActionResult> Index()
        {
            var LoggedInUser = await _context.Customers.FindAsync(userManager.GetUserId(HttpContext.User));
            ViewBag.LoggedUserName = LoggedInUser.Name;
            IEnumerable<PostData> ls = _context.PostDatas;
            foreach(PostData pd in ls)
            {
                pd.richtext_file_path = System.IO.File.ReadAllText(pd.richtext_file_path);
            }
            return View(ls);
        }


        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
