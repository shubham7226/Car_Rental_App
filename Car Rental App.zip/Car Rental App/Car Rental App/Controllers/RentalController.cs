﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Car_Rental_App.Models;
using Car_Rental_App.ViewModel;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Car_Rental_App.Controllers
{
    public class RentalController : Controller
    {
        private readonly AppDbContext _context;
        private readonly IWebHostEnvironment _env;
        private readonly UserManager<Customer> userManager;
        private readonly SignInManager<Customer> signInManager;
        public RentalController(AppDbContext context,
                             UserManager<Customer> userManager,
                              IWebHostEnvironment env,
                             SignInManager<Customer> signInManager)
        {
            _context = context;
            this.userManager = userManager;
            this.signInManager = signInManager;
            _env = env;
        }

        public IActionResult RentalPlatform()
        {
            return View();
        }

        public async Task<IActionResult> AvailableCars(CarSearchViewModel model)
        {
            var TotalCars = await _context.cars.ToListAsync();
            var TotalDrivers = await _context.Drivers.ToListAsync();
            
            var NotAvailableCars = _context.Reservations.Include(x => x.Car).
                Where(x => !(x.DropDate < model.PickupDate || x.PickupDate > model.DropDate)).ToList();

            var NotAvailableDrivers = _context.Reservations.Include(x => x.Driver).
                Where(x => !(x.DropDate < model.PickupDate || x.PickupDate > model.DropDate)).ToList();

            foreach (var car in NotAvailableCars)
            {
                TotalCars.Remove(car.Car);
            }

            foreach (var driver in NotAvailableDrivers)
            {
                TotalDrivers.Remove(driver.Driver);
            }
            
            
            RentCarViewModel rent = new RentCarViewModel();
            rent.cars = TotalCars;
            rent.Source = model.Source;
            rent.Destination = model.Destination;
            rent.PickupDate = model.PickupDate;
            rent.DropDate = model.DropDate;
            ViewBag.StartDate = model.PickupDate;
            ViewBag.EndDate = model.DropDate;
            
            return View(rent);
        }

        public async Task<IActionResult> AvailableDrivers(int id, string source, string destination, string StartDate, string EndDate)
        {
            var TotalDrivers = await _context.Drivers.ToListAsync();

            var NotAvailableDrivers = _context.Reservations.Include(x => x.Driver).
                Where(x => !(x.DropDate < Convert.ToDateTime(StartDate) || 
                             x.PickupDate > Convert.ToDateTime(EndDate))).ToList();

            foreach (var driver in NotAvailableDrivers)
            {
                TotalDrivers.Remove(driver.Driver);
            }


            SelectDriverViewModel rent = new SelectDriverViewModel();
            rent.Drivers = TotalDrivers;
            ViewBag.CarId = id;
            ViewBag.source = source;
            ViewBag.destination = destination;
            ViewBag.StartDate = StartDate;
            ViewBag.EndDate = EndDate;
            
            return View(rent);
        }

        /*
        public async Task<IActionResult> RentCar(int id, string source, string destination, string StartDate, string EndDate)
        {
            var rentCar = await _context.cars.FindAsync(id);
            
            Reservation newReservation = new Reservation
            {
                PickupLocation = source,
                DropLocation = destination,
                PickupDate = Convert.ToDateTime(StartDate),
                DropDate = Convert.ToDateTime(EndDate),
                Amount = 250,
                CarVIN = rentCar.VIN,
                Car = rentCar,
                BookingTime = DateTime.Now,
                Customer = await _context.Customers.FindAsync(userManager.GetUserId(HttpContext.User))
            };

            _context.Reservations.Add(newReservation);
            _context.SaveChanges();
            return RedirectToAction("index", "car");
        }
        */
        public async Task<IActionResult> RentedCars()
        {
            var Reservations = await _context.Reservations.ToListAsync();
            var LoggedInUser = await _context.Customers.FindAsync(userManager.GetUserId(HttpContext.User));

            List<RentedCarsViewModel> bookings = new List<RentedCarsViewModel>();//Rental Menu For Users
            List<RentedCarsViewModel> ForAdmin = new List<RentedCarsViewModel>();//Rental Menu For Admin
            
            Stack myStack = new Stack();
            Stack adminStack = new Stack();
            
            var YourBookings = _context.Reservations.Include(x => x.Customer)
                .Where(x => x.Customer == LoggedInUser).ToList();

            foreach (var item in Reservations)
            {
                var car = await _context.cars.FindAsync(item.CarId);
                var customer = await _context.Customers.FindAsync(item.CustomerId);
                string SelectedDName;
                int driver_id = item.Driver_Id;
                if (driver_id != 0)
                {
                    Driver obj = await _context.Drivers.FindAsync(driver_id);
                    SelectedDName = obj.Name;
                }
                else
                    SelectedDName = "Not Selected";

                RentedCarsViewModel x = new RentedCarsViewModel
                {
                    ReservationId = item.ReservationId,
                    PickupLocation = item.PickupLocation,
                    DropLocation = item.DropLocation,
                    PickupDate = item.PickupDate,
                    DropDate = item.DropDate,
                    Amount = item.Amount,
                    CarVIN = item.CarVIN,
                    BookingTime = item.BookingTime,
                    CarId = item.CarId,
                    Car = item.Car,
                    CustomerId = item.CustomerId,
                    Customer = item.Customer,
                    CarImagePath = car.PhotoPath,
                    UserName = customer.UserName,
                    DriverName = SelectedDName,
                    Status = true
                };
                
                if (item.PickupDate < DateTime.Now)
                    x.Status = false;
                
                if (item.Customer == LoggedInUser)
                {
                    myStack.Push(x);
                    //bookings.Add(x);
                }
                //ForAdmin.Add(x);
                adminStack.Push(x);
            }
            foreach (var elem in myStack)
            {
                bookings.Add((RentedCarsViewModel)elem);
            }
            foreach (var elem in adminStack)
            {
                ForAdmin.Add((RentedCarsViewModel)elem);
            }


            if (bookings.Count > 0)
                ViewBag.HasRentedOnceTime = 1;
            if (signInManager.IsSignedIn(User) && User.IsInRole("Admin"))
            {
                return View(ForAdmin);
            }
            return View(bookings);
        }

        [HttpGet]
        public async Task<IActionResult> CancelReservation(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var reservation = await _context.Reservations
                .FirstOrDefaultAsync(m => m.ReservationId == id);
            if (reservation == null)
            {
                Response.StatusCode = 404;
                return View("CarNotFound", id);
            }
            var carId = reservation.CarId;
            var customerId = reservation.CustomerId;
            var car = await _context.cars.FindAsync(carId);
            var customer = await _context.Customers.FindAsync(customerId);
            ViewBag.CarImagePath = car.PhotoPath;
            ViewBag.UserName = customer.UserName;
            return View(reservation);
        }

        [HttpPost, ActionName("CancelReservation")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CancelReservationConfirmed(int id)
        {
            var reservation = await _context.Reservations.FindAsync(id);
            _context.Reservations.Remove(reservation);
            await _context.SaveChangesAsync();
            return RedirectToAction("RentedCars", "Rental");
        }

        [HttpGet]
        public async Task<IActionResult> AddReview()
        {
            var LoggedInUser = await _context.Customers.FindAsync(userManager.GetUserId(HttpContext.User));
            List<Reservation> YourBookings = _context.Reservations.Include(x => x.Customer)
                .Where(x => x.Customer == LoggedInUser).ToList();
            if (YourBookings.Count == 0)
                return RedirectToAction("AccessDenied", "Account");
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> AddReview(PostDataViewModel model)
        {
            var LoggedInUser = await _context.Customers.FindAsync(userManager.GetUserId(HttpContext.User));
            
            PostData obj = new PostData();
            obj.uid = LoggedInUser.Id;
            obj.UserName = LoggedInUser.Name;
            obj.uploadtime = DateTime.Now;
            obj.title = model.title;
            string filepath;
            string folderPath = "Media/";
            folderPath += Guid.NewGuid().ToString() + "_" + RandomFileName(6);
            filepath = Path.Combine(_env.WebRootPath, folderPath);
            filepath += ".txt";
            System.IO.File.WriteAllText(filepath, model.textfile);
            obj.richtext_file_path = filepath;
            _context.PostDatas.Add(obj);
            _context.SaveChanges();
            return View();
        }

        private static Random random = new Random();
        public static string RandomString(int length)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            return new string(Enumerable.Repeat(chars, length)
              .Select(s => s[random.Next(s.Length)]).ToArray());
        }

        public static string RandomFileName(int length)
        {
            const string chars = "abcdefghigklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            return new string(Enumerable.Repeat(chars, length)
              .Select(s => s[random.Next(s.Length)]).ToArray());
        }
    }
}